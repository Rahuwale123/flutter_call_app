import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  final TextEditingController phonenum=TextEditingController();
  @override
 Widget build(BuildContext context) => new Scaffold(
  appBar: AppBar(
    title: Text("make direct calls"),
  ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                 keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.digitsOnly
              ], 
                  controller: phonenum,
                  decoration: InputDecoration(
                    labelText: 'enter phone number',
                    border: OutlineInputBorder()
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(onPressed: (){

                    FlutterPhoneDirectCaller.callNumber(phonenum.text);
                }, child: Text("Call now")),
              )
            ],
          ),
        ),
      );
}